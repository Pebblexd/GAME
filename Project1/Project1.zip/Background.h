#pragma once
#include <SFML/Graphics.hpp>
class Background
{
	sf::RenderWindow* window;
	sf::Sprite background;
public:
	void SetWindowPtr(sf::RenderWindow* windowPtr);
	void drawBackground(sf::Texture texture);
};

