#pragma once
#include "Player.h"
#include "Background.h"
#include "Enemies.h"

#include <SFML/Window.hpp>
#include <SFML/Audio.hpp>
#include <windows.h>
/*
    Class that acts as the game engine.
    Wrapper class.
*/
class Game
{
private:
    //Variables
    //Window
    sf::RenderWindow* window;
    sf::VideoMode videoMode;
    sf::Event ev;

    //Game objects
    Player player;
    Background background;
    Enemies enemies;

    //Private functions
    void initVariables();
    void initWindow();
public:
    //Constructors & Desturctors
    Game();
    ~Game();
    //Accessors
    const bool running() const;
    //Functions
    void pollEvents();
    void update();
    void render(sf::Texture _background, sf::Texture ball, sf::Texture enemy);
    sf::RenderWindow* getWindow();
    void input();
};