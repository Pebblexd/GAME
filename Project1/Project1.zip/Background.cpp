#include "Background.h"

void Background::SetWindowPtr(sf::RenderWindow* windowPtr)
{
    window = windowPtr;
}

void Background::drawBackground(sf::Texture texture)
{
    background.setTexture(texture);
    window->draw(background);
}