#include "Enemies.h"
#include <iostream>

void Enemies::SetWindowPtr(sf::RenderWindow* windowPtr)
{
	window = windowPtr;
}

Enemies::Enemies()
{
	for(int i = 0 ; i < 20 ; i++)
		setStartingPosition(enemies[i]);
}

void Enemies::setStartingPosition(sf::Sprite& enemy)
{
	std::mt19937::result_type seed = std::chrono::high_resolution_clock::now().time_since_epoch().count();
	auto dice_rand = std::bind(std::uniform_int_distribution<int>(1, 4), std::mt19937(seed));
	auto dice_randY = std::bind(std::uniform_int_distribution<int>(0, 670), std::mt19937(seed));
	auto dice_randX = std::bind(std::uniform_int_distribution<int>(0, 1230), std::mt19937(seed));
	int choice = dice_rand();
	switch (choice)
	{
		//left wall
		case 1:
		{
			int positionY = dice_randY();
			enemy.setPosition(-50, positionY);
			enemy.setRotation(90);
			break;
		}
		//top
		case 2:
		{
			int positionX = dice_randX();
			enemy.setPosition(positionX, -50);
			enemy.setRotation(180);
			break;
		}
		//right wall
		case 3:
		{
			int positionY = dice_randY();
			enemy.setPosition(1330, positionY);
			enemy.setRotation(270);
			break;
		}
		//bottom
		case 4:
		{
			int positionX = dice_randX();
			enemy.setPosition(positionX, 770);
			enemy.setRotation(0);
			break;
		}
	}
}

void Enemies::moveEnemies()
{
	for (int i = 0; i < 20; i++)
	{
		if (enemies.at(i).getRotation() == 90 && enemies.at(i).getTexture() != nullptr)
		{
			if (velocityChange <= 5)
				velocityChange += 0.1f;
			enemies.at(i).move(sf::Vector2f(velocityChange, 0));
		}
		else if (enemies.at(i).getRotation() == 180 && enemies.at(i).getTexture() != nullptr)
		{
			if (velocityChange <= 5)
				velocityChange += 0.1f;
			enemies.at(i).move(sf::Vector2f(0, velocityChange));
		}
		else if (enemies.at(i).getRotation() == 270 && enemies.at(i).getTexture() != nullptr)
		{
			if (velocityChange <= 5)
				velocityChange += 0.1f;
			enemies.at(i).move(sf::Vector2f(-velocityChange, 0));
		}
		else if(enemies.at(i).getTexture() != nullptr)
		{
			if (velocityChange <= 5)
				velocityChange += 0.1f;
			enemies.at(i).move(sf::Vector2f(0, -velocityChange));
		}
	}
}

void Enemies::drawEnemies(sf::Texture texture)
{
	for (int i = 0; i <= maxEnemies; i++)
	{
		enemies.at(i).setTexture(texture);
		window->draw(enemies.at(i));
	}
	time += clock.getElapsedTime().asSeconds();
	if (time > 10)
	{
		time = 0;
		if(maxEnemies <19)
			maxEnemies++;
		clock.restart();
	}
}
