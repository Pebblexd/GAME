#pragma once
#include<SFML/Graphics.hpp>
#include<array>
#include <random>
#include <functional>
#include <chrono>

class Enemies
{
	sf::RenderWindow* window;
	std::array<sf::Sprite, 20> enemies;
	float velocityChange;
	sf::Clock clock;
	int maxEnemies = 0;
	float time = 0;
public:
	void SetWindowPtr(sf::RenderWindow* windowPtr);
	void drawEnemies(sf::Texture texture);
	void moveEnemies();
	void setStartingPosition(sf::Sprite& enemy);
	Enemies();
};

