#include "Player.h"


void Player::SetWindowPtr(sf::RenderWindow* windowPtr)
{
    window = windowPtr;
}

Player::Player()
{
    ball.setPosition(605, 335);
}

void Player::drawBall(sf::Texture _ball)
{
    ball.setTexture(_ball);
    window->draw(ball);
}

void Player::moveBall()
{
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
    {
        if (ball.getPosition().x > 0)
        {
            if (velocityChange <= 5)
                velocityChange += 0.1f;

            ball.move(sf::Vector2f(-velocityChange, 0));
        }
    }

    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
    {
        if (ball.getPosition().y > 0)
        {
            if (velocityChange <= 5)
                velocityChange += 0.1f;

            ball.move(sf::Vector2f(0, -velocityChange));
        }
    }

    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
    {
        if (ball.getPosition().x < (1280 - 50))
        {
            if (velocityChange <= 5)
                velocityChange += 0.1f;

            ball.move(sf::Vector2f(velocityChange, 0));
        }
    }

    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
    {
        if (ball.getPosition().y < (720 - 50))
        {
            if (velocityChange <= 5)
                velocityChange += 0.1f;

            ball.move(sf::Vector2f(0, velocityChange));
        }
    }
}
