#pragma once
#include <SFML/Graphics.hpp>
#include <iostream>
class Player
{
private:
    sf::RenderWindow* window;
    sf::Sprite ball;
    float velocityChange;
public:
    void SetWindowPtr(sf::RenderWindow* windowPtr);
    Player();
    void drawBall(sf::Texture _ball);
    void moveBall();
};

