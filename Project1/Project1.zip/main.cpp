#include "Game.h"

int main()
{   
    sf::Texture background;
    background.loadFromFile("Images/background.png");

    sf::Texture ball;
    ball.loadFromFile("Images/player.png");

    sf::Texture enemy;
    enemy.loadFromFile("Images/enemy.png");

    //Init Game Engine
    Game game;

    sf::Music music;
    music.openFromFile("Sounds/Soliloquy.ogg");
    music.setVolume(1);
    music.setLoop(true);
    music.play();

    //Game loop
    while(game.running())
    {
        game.input();

        //Update
        game.update();

        //Render
        game.render(background, ball, enemy);
    }

    //End of Game
    return 0;
}